import { designers } from "./data/designer.js";

let designersHTML = '';

designers.forEach((designer) => {
  designersHTML += `
        <div class="designers">
        <div class="designer-image">
          <img src="${designer.image}" class="designer-img">
        </div>
        <div class="designer-name">
          <h3>${designer.name}</h3>
        </div>
        <div class="designer-bio">
          <p>${designer.bio}</p>
        </div>
        <button class="learnMore">Learn more...</button>
      </div> 
  `
});
console.log(designersHTML)
document.querySelector('.js-designer-container').innerHTML = designersHTML;