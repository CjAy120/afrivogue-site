export const designers = [
  {
    image: 'images/pedro-vit-nxssxDuytMA-unsplash.jpg',
    name : 'Pedro Vit',
    bio : 'Pedro Vits is a Lisbon-based designer known for edgy, urban fashion with sharp cuts and a rebellious spirit. His work challenges trends with confidence'
  },
  {
    image: 'images/pexels-godisable-jacob-226636-794064.jpg',
    name : 'Akosua Mends',
    bio : 'Akosua Mends creates bold, handcrafted pieces inspired by African folklore and textiles. Each design tells a story with vibrant colors and striking shapes'
  },
  {
    image: 'images/shutterstock_258257798-scaled.jpg',
    name : 'Nana Badu',
    bio : 'Nana Badu blends traditional West African patterns with sleek modern tailoring. His designs celebrate heritage while pushing fashion forward'
  },
  {
    image: 'images/front-view-confident-woman-studio_23-2148410798.jpg',
    name : 'Ama Serwaa',
    bio : 'Ama Serwaa is known for her elegant, minimalist womenswear infused with soft colors and subtle Ghanaian influences. Graceful, timeless, and refined'
  },
  {
    image: 'images/marjan-sadeghi-TrQFdQ2awP8-unsplash.jpg',
    name : 'Jaxon Reeve',
    bio : 'Elira Vontelle is a French designer celebrated for merging 1950s elegance with contemporary silhouettes. Her timeless pieces often feature soft textures, delicate stitching, and a touch of modern drama.'
  },
  {
    image: 'images/darling-arias-0tBvf_HJ34c-unsplash.jpg',
    name : 'Elira Vontelle',
    bio : 'Elira Vontelle is a French designer celebrated for merging 1950s elegance with contemporary silhouettes. Her timeless pieces often feature soft textures, delicate stitching, and a touch of modern drama.'
  }
]