const slides = 
document.querySelectorAll('.slide');
  let current = 0;

  setInterval(() => {

    slides[current].classList.remove('active');
      current = (current + 1) % 
    slides.length;

    slides[current].classList.add('active');
  }, 5000);
  
  function jumpToSelection(select) {
    const targetId = select.value;
    if(targetId) {
      const element = 
    document.getElementById(targetId);
    if(element){
      element.scrollIntoView({ behavior: "smooth" });
    }
    }
  }

  const applyBtn = document.querySelectorAll('.apply');

  applyBtn.forEach((button) => {
    button.addEventListener('click', () => {
      button.innerHTML = 'Applied';
    })
  })

  function toggleMenu() {
  const navLinks = document.getElementById("navLinks");
  navLinks.classList.toggle("show");
}
function toggleMenu() {
      document.getElementById('navLinks').classList.toggle('show');
}